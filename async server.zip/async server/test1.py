#Find substring in a string without any repeating character
import sys
def longest_substring(str1):
    tempstr=None
    max=-sys.maxsize
    temp=list()
    if len(str1)==0:
        return 0
    for i in range(0,len(str1)):
       temp.append(str1[i])
       if (i+1)<len(str1):
            for j in range(i+1,len(str1)):
                if str1[j] not in temp:
                    temp.append(str1[j])
                else:
                    break
       if len(temp)>max:
           max=len(temp)
           tempstr=''.join(temp)
       temp.clear()
    return tempstr

if __name__=="__main__":
   print(longest_substring("bapanbiswas"))
   print(longest_substring("sumanmehta"))
   print(longest_substring("abcdeadafsghhbv"))





   
         